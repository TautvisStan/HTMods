# UnlimitedReversals
Will apply to your character. If possible, all strikes, grapple moves and submissions will be reversed as long as you hold the attack button. Note that there are a bunch of non-reversable moves. Non-reversable submissions will instantly be broken instead.

It doesn't seem to be working as well as in Empire, but maybe it's just because in this game you usually fight multiple people at once and most of them carry weapons.

Additional option in the config file lets you to disable botches (where both characters fall down instead).

JOIN OUR HARD TIME III MODDING DISCORD SERVER: https://discord.gg/zWzRCTHMdS

[![Support](https://storage.ko-fi.com/cdn/brandasset/kofi_button_dark.png)](https://ko-fi.com/gamingmasterlt "Support me on Ko-fi")