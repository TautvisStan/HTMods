# MultiBind

This mod lets players rebind their keyboard controls and share a single keyboard. Thanks to Nifty for an idea.

You can now toggle a controller mode by pressing numpad enter in the main menu. This mode will trick the game into thinking your keyboard is a xbox controller, allowing you to navigate the menus using the keyboard without the need of mouse.

Now supports rebinding buttons to the mouse. `Mouse0` - left mouse button, `Mouse1` - right mouse button, `Mouse2` - middle mouse button, `Mouse3` `Mouse4` `Mouse5` `Mouse6` - additional buttons on your mouse (you will have to figure out these yourself)

Controls can be changed in the mod config file. Keybinds that can be changed:
- Movement (arrow keys)
- Attack (A) (West button in the controller mode)
- Grapple (S) (North button in the controller mode)
- Run (Z) (South button in the controller mode)
- Pick up (X) (East button in the controller mode)
- Taunt (Space)
- Change focus (Control and Shift) (Right and Left shoulder buttons in the controller mode)
- Change control (Tab)(Right trigger in the controller mode)
- (NEW) Left trigger for the use in controller mode.
- Join the game (NEW) - previously was only available on the controller, now you can join a match in progress (eg. AI only match)

Changing `Esc` and `P` to different buttons is currently not supported.

Pressing `+` on numpad while in the main menu will add a keyboard player, pressing `-` will remove them instead. Supports up to 3 additional players. Controls for each player can be customized in the config file. Additional players can also join the free roam by pressing the Join button.

NOTE: Going into controller calibration screen will break added keyboard players. Press Refresh to remove them then add them again in the main menu.

NOTE: This mod may or may not break with an existing controller plugged in.

JOIN OUR HARD TIME III MODDING DISCORD SERVER: https://discord.gg/zWzRCTHMdS

[![Support](https://storage.ko-fi.com/cdn/brandasset/kofi_button_dark.png)](https://ko-fi.com/gamingmasterlt "Support me on Ko-fi")